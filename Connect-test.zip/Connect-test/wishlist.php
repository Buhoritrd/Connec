<?php
include "header.php";
?>


<section class="section">
<div class="container-fluid">	
    <div id="wishlist_data">
    </div>
</div>
</section>	
<?php
include "newslettter.php";
include "footer.php";
?>